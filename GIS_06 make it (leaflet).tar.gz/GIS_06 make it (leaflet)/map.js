window.onload = function(){

var map = new L.Map('map');

var cloudmade = new L.TileLayer('http://{s}.tile.cloudmade.com/BC9A493B41014CAABB98F0471D759707/997/256/{z}/{x}/{y}.png', {
    attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://cloudmade.com">CloudMade</a>',
    maxZoom: 18
});

var location = new L.LatLng( 60.293165, -158.959803 ); // geographical point (longitude and latitude)
map.setView(location, 13).addLayer(cloudmade);


var geojsonLayer = new L.GeoJSON();
map.addLayer(geojsonLayer);

var geojsonFeature = {
    "type": "FeatureCollection",
    "features": [
    { "type": "Feature", "properties": { "id": 1, "nama": "Wood-tikchik" }, "geometry": { "type": "Point", "coordinates": [ -158.959803, 60.293165 ] } }
    ,
    { "type": "Feature", "properties": { "id": 2, "nama": "Lake Clark National Park" }, "geometry": { "type": "Point", "coordinates": [ -154.525763, 60.265959 ] } }
    ,
    { "type": "Feature", "properties": { "id": 3, "nama": "Bethel" }, "geometry": { "type": "Point", "coordinates": [ -161.747541, 60.792412 ] } }

    ]
};

geojsonLayer.addGeoJSON(geojsonFeature);

}
